/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang( 'stylescombo', 'af', {
	label: 'Styl',
	panelTitle: 'Opmaak style',
	panelTitle1: 'Blok style',
	panelTitle2: 'Inlyn style',
	panelTitle3: 'Objek style'
});
