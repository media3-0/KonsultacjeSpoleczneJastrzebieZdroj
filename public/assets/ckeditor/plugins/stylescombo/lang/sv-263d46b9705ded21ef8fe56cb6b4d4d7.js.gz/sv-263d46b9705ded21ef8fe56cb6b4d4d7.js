/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang( 'stylescombo', 'sv', {
	label: 'Anpassad stil',
	panelTitle: 'Formatmallar',
	panelTitle1: 'Blockstil',
	panelTitle2: 'Inbäddad stil',
	panelTitle3: 'Objektets stil'
});
