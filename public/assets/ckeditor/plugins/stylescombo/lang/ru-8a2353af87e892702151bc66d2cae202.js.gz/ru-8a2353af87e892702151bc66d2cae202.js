/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang( 'stylescombo', 'ru', {
	label: 'Стили',
	panelTitle: 'Стили форматирования',
	panelTitle1: 'Стили блока',
	panelTitle2: 'Стили элемента',
	panelTitle3: 'Стили объекта'
});
